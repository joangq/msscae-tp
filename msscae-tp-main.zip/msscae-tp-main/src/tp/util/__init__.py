from tp.util.interfaces import *
from tp.util.types import *
from tp.util.simulador import *